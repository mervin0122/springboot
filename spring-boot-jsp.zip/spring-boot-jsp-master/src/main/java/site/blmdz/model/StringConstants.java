package site.blmdz.model;

public class StringConstants {
	public final static String INFO = "info";
	public final static String ERRORS = "/error/page";
	public final static String PAGE_NOT_FOUND = "/error/404";
}
