package site.blmdz.auth;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.yaml.snakeyaml.Yaml;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Splitter;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.io.Resources;

import lombok.extern.slf4j.Slf4j;

/**
 * 权限读取工具类
 * @author yangyz
 * @date 2016年12月2日下午5:16:51
 */
@Slf4j
public class AuthUtils {
	static final ObjectMapper mapper = new ObjectMapper();
	static {
	}

	/**
	 * shiro auth
	 */
	public static Map<String, Auth> readAuths() {
		AuthFile auth = readFile();
		return Objects.isNull(auth) ? null : auth.getAuths();
	}
	/**
	 * roles auth
	 */
	public static Map<String, Auth> readRolesAuths() {
		AuthFile auth = readFile();
		return Objects.isNull(auth) ? null : auth.getRoles();
	}
	/**
	 * tree
	 */
	public static Map<String, Map<String, Node>> readTrees() {
		AuthFile auth = readFile();
		return Objects.isNull(auth) ? null : auth.getTree();
	}
	/**
	 * roles
	 */
	public static Set<String> readRoles() {
		AuthFile auth = readFile();
		return Objects.isNull(auth) ? null : auth.getTree().keySet();
	}
	/**
	 * auth tree Map
	 */
	public static Map<String, Node> readAuthsTreeMap() {
		AuthFile auth = readFile();
		if (Objects.isNull(auth))
			return null;
		
		Map<String, Node> mapTree = Maps.newLinkedHashMap();
		auth.getTree().keySet().forEach(role_key -> {
			build(mapTree, auth.getTree().get(role_key));
		});
		
		return mapTree;
	}
	/**
	 * admin
	 * normal
	 * admin, normal
	 * auth tree Map
	 */
	public static Map<String, Node> readAuthsRolesTreeMap(String role) {
		AuthFile auth = readFile();
		if (Objects.isNull(auth))
			return null;
		
		Map<String, Node> mapTree = Maps.newLinkedHashMap();
		
		Set<String> roles = Sets.newLinkedHashSet(Splitter.on(",").trimResults().splitToList(role.toLowerCase()));
		if (CollectionUtils.isNotEmpty(roles))
			roles.forEach(role_str -> {
				build(mapTree, auth.getTree().get(role_str));
			});
		
		return mapTree;
	}
	/**
	 * admin
	 * normal
	 * admin, normal
	 * auth tree
	 */
	public static Map<String, Node> readAuthsTree(String role) {
		AuthFile auth = readFile();
		if (Objects.isNull(auth))
			return null;
		Map<String, Node> mapTree = Maps.newLinkedHashMap();
		
		Set<String> roles = Sets.newLinkedHashSet(Splitter.on(",").trimResults().splitToList(role.toLowerCase()));
		if (CollectionUtils.isNotEmpty(roles))
			roles.forEach(role_str -> {
				mapTree.putAll(auth.getTree().get(role_str));
			});
		
		return mapTree;
	}
	/**
	 * requests
	 */
	public static Set<String> readRequests() {
		Set<String> requests = Sets.newLinkedHashSet();
		Map<String, Auth> auth = AuthUtils.readAuths();
		auth.keySet().forEach(item -> {
			requests.addAll(auth.get(item).getRequests());
		});
		Map<String, Auth> roles_auth = AuthUtils.readRolesAuths();
		roles_auth.keySet().forEach(item -> {
			requests.addAll(roles_auth.get(item).getRequests());
		});
		Map<String, Node> auth_tree = AuthUtils.readAuthsTreeMap();
		auth_tree.keySet().forEach(item -> {
			requests.add(auth_tree.get(item).getResources());
		});
		return requests;
	}

	public final static String FILE = "auth.yaml";
	protected static AuthFile readFile() {
		try {
			return new Yaml().loadAs(
					new FileInputStream(
							new File(
									Resources.getResource(FILE).getFile())),
									AuthFile.class);
		} catch (FileNotFoundException e) {
			log.error("auth file'config:{} not found." + FILE);
			return null;
		}
	}
	protected static void build(Map<String, Node> mapTree, Map<String, Node> map) {
		if (!Objects.isNull(map))
			map.keySet().forEach(auth_key -> {
				Node node = null;
				try {
					node = new Yaml().loadAs(mapper.writeValueAsString(map.get(auth_key)), Node.class);
				} catch (JsonProcessingException e) {
					return ;
				}
				mapTree.put(auth_key, new Node(node.getName(), node.getResources()));
				if (Objects.nonNull(node.getChildren()))
					build(mapTree, node.getChildren());
			});
	}
	
	
}
