# spring-boot-jsp
spring-boot + shiro + jsp + mybatis + mysql

jdk 1.8

###user:
	1. admin/111111
	2. normal/111111
